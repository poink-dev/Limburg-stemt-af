<?php
include './dbh.php';
$response = array();
$html = "";

// Fetch data from the database
$sql = "SELECT * FROM `qr-codes` ORDER BY `updatedAt`";
$statement = $conn->prepare($sql);
$statement->execute();
$results = $statement->get_result();

while ($row = $results->fetch_assoc()) {
    // Modal trigger button
    $html .= '<div class="row" value="'.$row['id'].'">
            <div class="col-2">
            <h2>'.$row["title"].'</h2>
            </div>
                        <div class="col-2">
            <P>'.$row["era"].'</P>
            </div>
            <div class="col-2">
            <img src="'.$row["image"].'" style="width:100%;height: 100%;">

            </div>
            <div class="col-2">
            <p>'.$row["content"].'</p>
            </div>
            <div class="col-2">
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=/schilderij.php?id=' . $row['id'] . '" style="width: 100px; height: 100px; margin-bottom: 5px;" alt="QR Code">
    <a target="_blank" href="./schilderij.php?id=' . $row['id'] . '" style="text-decoration: none; color: #000;">Link</a>

            </div>
            <div class="col-2">
                <button class="btn btn-info" style="margin:0.5rem;">download</button>
                <button class="btn btn-info" style="margin:0.5rem;" ><a href="./qr-code-edit.php?id='.$row['id'].'">change</a></button>
                <button class="btn btn-info" style="margin:0.5rem;" onclick="duplicate(\''.$row['title'].'\',\''.$row['era'].'\',\''.$row['image'].'\',\''.$row['content'].'\')">duplicate</button><br>
                <button class="btn btn-info" style="margin:0.5rem;" onclick="remove(\''.$row['id'].'\')">delete</button>
            </div>
        </div><br><br>';
}

// Return the generated HTML
echo json_encode($html);
