<?php

$name = $_GET['name']; 
