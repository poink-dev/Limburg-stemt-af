<?php
include 'dbh.php';
$response = array();
$era_name = $_POST['era_name'];
$start_year = $_POST['start_year'];
$end_year = $_POST['end_year'];
$id = generate_uuid_v4();
$sql = "INSERT INTO `historical_eras`(`id`, `era_name`, `start_year`, `end_year`) VALUES (?,?,?,?)";
$statement = $conn ->prepare($sql);
$statement -> bind_param('ssss' ,$id,$era_name,$start_year,$end_year,);
$statement->execute();

echo json_encode($response);

?>
