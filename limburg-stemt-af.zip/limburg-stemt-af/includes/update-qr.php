<?php
include "./dbh.php";
$response = array();

$title = $_POST['title'];
$content = $_POST['content'];
$era = $_POST['era'];
$image = $_POST['image'];
$id = $_POST['id'];



$sql = "UPDATE `qr-codes` SET `title` = ?, `content` = ?, `era` = ?, `image` = ? WHERE `id` = ?";
$statement = $conn->prepare($sql);


$statement->bind_param('sssss', $title, $content, $era, $image,$id);

$statement->execute();

echo json_encode($response);


?>