<?php
include './dbh.php';
$response = array();
$html = "";

// Fetch data from the database
$sql = "SELECT * FROM `historical_eras` ORDER BY `start_year`";
$statement = $conn->prepare($sql);
$statement->execute();
$results = $statement->get_result();

while ($row = $results->fetch_assoc()) {
    // Modal trigger button
    $html .= '
            <option value="'.$row['era_name'].'">  '.$row['era_name'].'('.$row['start_year'].';'.$row['end_year'].')</option>
    ';
}

// Return the generated HTML
echo json_encode($html);
