<?php
include 'dbh.php';
$response = array();
$title = $_POST['title'];
$era = $_POST['era'];
$image = $_POST['image'];
$content = $_POST['content'];
$id = generate_uuid_v4();
$sql = "INSERT INTO `qr-codes`(`id`, `title`, `era`, `image`,`content`) VALUES (?,?,?,?,?)";
$statement = $conn ->prepare($sql);
$statement -> bind_param('sssss' ,$id,$title,$era,$image,$content);
$statement->execute();

echo json_encode($response);

?>
