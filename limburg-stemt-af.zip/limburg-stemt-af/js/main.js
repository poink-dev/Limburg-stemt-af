function show() {
    $.ajax({
        url: "./includes/show-qr.php",
        data: {},
        method: "POST",
        dataType: 'json',
        success: function(data) {
            $('#list-qr').html(data);

        }
    });
}
$(document).ready(function() {
    show();
});