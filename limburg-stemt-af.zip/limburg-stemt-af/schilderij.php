<?php
include('./includes/dbh.php'); 

if (isset($_GET['id'])) {     
    $id = $_GET['id'];     
    $sql = "SELECT * FROM `qr-codes` WHERE `id` = ?";     
    $stmt = $conn->prepare($sql);     
    $stmt->bind_param("s", $id);     
    $stmt->execute();     
    $result = $stmt->get_result(); 

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();     
        $title = $row['title'];     
        $content = $row['content'];     
        $era = $row['era'];     
        $image = $row['image']; 
    } else {
        echo "Geen resultaat gevonden voor dit ID.";
        exit;
    }
} else {     
    echo "Geen id gevonden!";
    exit; 
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/ui/trumbowyg.min.css">
    <link rel="stylesheet" href="./style/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Onepager - Schilderij</title>
    <script>
        // Functie om de tekst voor te lezen
        function speakText() {
            // Selecteer de tekst die voorgelezen moet worden
            const descriptionText = document.getElementById("description-text").innerText;

            // Maak een SpeechSynthesis instantie
            const speech = new SpeechSynthesisUtterance(descriptionText);

            // Stel de taal in op Nederlands
            speech.lang = 'nl-NL';

            // Speel de tekst af
            window.speechSynthesis.speak(speech);
        }
    </script>
</head>
<body>
    <input type="hidden" id="QRid" name="id" value="<?php echo $row["id"]?>">   

    <header>
        <h1><?php echo $row["title"] ?></h1>
    </header>

    <div class="container">
        <section class="artwork">
        <img src="<?php echo $row['image']; ?>" alt="Artwork image">

        </section>

        <section class="description" id="description-text">
            <p><?php echo $row["content"] ?></p>
        </section>

        <button class="cta-btn" onclick="speakText()">Laat AI de tekst voorlezen</button>
    </div>

    <footer>
        <p>&copy; 2025 Tuur Verweijen | <a href="#privacy-policy">Privacybeleid</a></p>
    </footer>

</body>
</html>
