<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Your JS -->
    <script src="./js/main.js"></script>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            padding-top: 2rem;
        }

        header {
            margin-bottom: 2rem;
            text-align: center;
        }

        header .btn {
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
        }

        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 1.2rem;
        }

        .table td img {
            max-width: 100px;
            height: auto;
            border-radius: 6px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .btn-action {
            margin: 0.25rem;
            padding: 0.4rem 0.8rem;
            font-size: 0.9rem;
            border-radius: 0.3rem;
            color: white;
            background-color: #28a745;
            border: none;
        }

        .btn-action:hover {
            background-color: #218838;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .btn-warning {
            background-color: #ffc107;
            color: black;
        }

        .btn-warning:hover {
            background-color: #e0a800;
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        @media (max-width: 768px) {
            .card-header {
                font-size: 1rem;
            }

            .table-responsive {
                font-size: 0.9rem;
            }

            header .btn {
                width: 100%;
                margin-bottom: 1rem;
            }
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header class="container text-center">
        <a href="./qr-code-make.php" class="btn btn-primary btn-lg">
            Make a New Site
        </a>
    </header>

    <!-- Table Section -->
    <div class="container">
        <div class="card">
            <div class="card-header">QR Code Dashboard</div>
            <div class="card-body table-responsive">
                <table class="table table-hover align-middle text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>Title</th>
                            <th>Era</th>
                            <th>Image</th>
                            <th>Text</th>
                            <th>QR Code</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="list-qr">
                        <!-- JavaScript will populate this -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- JavaScript Functions -->
    <script>
        function duplicate(title, era, image, content) {
            $.ajax({
                url: 'includes/duplicate-qr.php',
                type: 'POST',
                data: { title, era, image, content },
                dataType: 'json',
                success: function (data) {
                    show();
                }
            });
        }

        function remove(id) {
            $.ajax({
                url: 'includes/delete-qr.php',
                type: 'POST',
                data: { id },
                dataType: 'json',
                success: function (data) {
                    show();
                }
            });
        }

        function show() {
            // Dummy loader - replace with your real logic
            $('#list-qr').html('<tr><td colspan="6">Loading...</td></tr>');
            $.get('includes/fetch-qr.php', function (data) {
                $('#list-qr').html(data);
            });
        }

        // Call show on load
        $(document).ready(function () {
            show();
        });
    </script>
</body>

</html>
