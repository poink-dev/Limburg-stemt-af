<?php
session_start();
// if (!isset($_SESSION['user'])) {
//     header("Location: index.php");
//     exit;
// }

include('./includes/dbh.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM `qr-codes` WHERE `id` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    $row = $result->fetch_assoc();
    $title = $row['title'];
    $content = $row['content'];
    $era = $row['era'];
    $image = $row['image'];
} else {
    echo "Geen id gevonden!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/ui/trumbowyg.min.css">

</head>

<body>

    <h2>Bewerken</h2>

    <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">

    <div class="mb-3">
        <label for="title" class="form-label">Titel</label>
        <input type="text" class="form-control" id="title" name="title" value="<?php echo $row['title']; ?>" placeholder="give a new title">
    </div>

    <div class="mb-3">
        <label for="content" class="form-label">Tekst</label>
        <textarea id="content" name="content" class="form-control" placeholder="give new content"><?php echo $content; ?></textarea>
    </div>

    <div class="mb-3">
        <label for="tijdsperk" class="form-label">Tijdperk</label>
        <input type="text" class="form-control" id="era" name="tijdsperk" value="<?php echo $row['era']; ?>" placeholder="Voer een tijdperk in">
    </div>

    <div class="mb-3">
        <label for="image" class="form-label">Afbeelding URL</label>
        <input type="text" class="form-control" id="image" name="image" value="<?php echo $row['image']; ?>" placeholder="Geef de image URL">
    </div>

    <div onclick="updateQR()" class="btn btn-primary" style="cursor:pointer;">Opslaan</div>
    <div id="errorMessageUpdate" class="alert alert-danger mt-3 text-center" style="display: none;"></div>
    <div id="succesMessageUpdate" class="alert alert-succes mt-3 text-center" style="display: none;"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.25.1/trumbowyg.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialiseer Trumbowyg-editor
            $('#content').trumbowyg();


        });

        function updateQR() {
            const title = $('#title').val();
            const content = $('#content').val();
            const era = $('#era').val();
            const image = $('#image').val();
            const id = $('#id').val();


            $.ajax({
                url: './includes/update-qr.php',
                method: 'POST',
                data: {
                    title,
                    content,
                    era,
                    image,
                    id
                },
                success: function(data) {
            window.location.href = "./index.php";

                }
            });
        }
    </script>
</body>

</html>