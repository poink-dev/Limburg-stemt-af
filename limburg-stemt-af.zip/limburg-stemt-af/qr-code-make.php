<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR-code make</title>

    <!-- Trumbowyg CSS from jsDelivr CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/trumbowyg@2.25.1/dist/ui/trumbowyg.min.css">

    <!-- jQuery (correct version before Trumbowyg JS) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Trumbowyg JS from jsDelivr CDN -->
    <script src="https://cdn.jsdelivr.net/npm/trumbowyg@2.25.1/dist/trumbowyg.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 20px auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }

        #qr-code {
            display: block;
            width: 150px;
            height: 150px;
            background: #f3f3f3;
            text-align: center;
            line-height: 150px;
            margin-bottom: 15px;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
        a{
        color: white;
        text-decoration:none;
    }
    </style>
</head>

<body>
    <h2>Make QR-code</h2>

    <div class="form-group">
        <h3>title</h3>
        <input type="text" id="title" placeholder="type title here">
    </div>

    <div class="form-group">
        <h3>QR-code</h3>
        <div id="qr-code">[QR Code]</div>
    </div>

    <div class="form-group">
        <h3>text</h3>
        <textarea id="editor"></textarea>
    </div>

    <div class="form-group">
        <h3>era</h3>
        <select id="era">

        </select>
    </div>
    <button ><a href="./addEra.php">add era</a></button>

    <div class="form-group">
        <h3>chose image</h3>
        <input type="text" id="image">
    </div>

    <button id="opslaan" onclick="make_qr()">Opslaan</button>

    <script>
        $(document).ready(function() {
            // Check if Trumbowyg is loaded correctly
            if (typeof $.fn.trumbowyg !== 'undefined') {
                // Initialize Trumbowyg editor
                $('#editor').trumbowyg();
            } else {
                console.error("Trumbowyg was not loaded correctly.");
            }
        });

        $(document).ready(function() {
            showEra()
        });

        function make_qr() {
    // Get the values of the inputs
    const title = $('#title').val();
    const era = $('#era').val();
    const image = $('#image').val();
    const content = $('#editor').trumbowyg('html'); // Get the content from the Trumbowyg editor

    console.log(title, era, image, content); // Debug log to see the variables

    // Send the data via AJAX
    $.ajax({
        url: 'includes/duplicate-qr.php',
        type: 'POST',
        data: {
            title: title,
            era: era,
            image: image,
            content: content
        },
        dataType: 'json',
        success: function(data) {
            window.location.href = "./index.php";

        }
    });
}

function showEra() {
    // Send the data via AJAX
    $.ajax({
        url: 'includes/get-eras.php',
        type: 'POST',
        data: {
        },
        dataType: 'json',
        success: function(data) {
            $('#era').html(data)

        }
    });
}



    </script>
</body>

</html>