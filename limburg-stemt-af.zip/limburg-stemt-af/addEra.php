<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Trumbowyg JS from jsDelivr CDN -->
<script src="https://cdn.jsdelivr.net/npm/trumbowyg@2.25.1/dist/trumbowyg.min.js"></script>



  <title>Era Tracker</title>
  <style>
            button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
    a{
        color: white;
        text-decoration:none;
    }
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    input, button {
      padding: 8px;
      margin: 5px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ddd;
    }
  </style>
</head>
<body>
  <h2>Add an Era</h2>
  <form id="eraForm">
    <input type="text" id="name" placeholder="Era Name" required />
    <input type="number" id="startYear" placeholder="Start Year" required />
    <input type="number" id="endYear" placeholder="End Year" required />
    <button type="BUTTON" onclick="addEra()">Add Era</button>
  </form>

  <h3>Era List</h3>

    <div id="era"></div>

    <button><a href="./index.php">go back</a> </button>
  <script>
        $(document).ready(function() {
            showEra()
        });
function showEra() {
    // Send the data via AJAX
    $.ajax({
        url: 'includes/get-eras.php',
        type: 'POST',
        data: {
        },
        dataType: 'json',
        success: function(data) {
            $('#era').html(data)

        }
    });
}


function addEra() {
    var era_name = $('#name').val()
    var start_year = $('#startYear').val()
    var end_year = $('#endYear').val()

    // Send the data via AJAX
    $.ajax({
        url: 'includes/addEra.php',
        type: 'POST',
        data: {
            era_name,
            start_year,
            end_year
        },
        dataType: 'json',
        success: function(data) {
            window.location.href = "./addEra.php";



        }
    });
}
  </script>
</body>
</html>
